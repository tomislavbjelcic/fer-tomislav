package ui;

public interface State {
	
}
